#ifndef TYPES_H
#define TYPES_H
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>


typedef enum{
	SUCCESS,FAILURE,LIST_EMPTY
}Status;
#endif

